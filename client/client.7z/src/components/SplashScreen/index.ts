import SplashScreen from "./SplashScreen";

export default SplashScreen;