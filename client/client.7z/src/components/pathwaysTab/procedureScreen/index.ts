import ProcedureScreen from "./ProcedureScreen";

export default ProcedureScreen;