import PathwayScreen from "./PathwayScreen";

export default PathwayScreen;